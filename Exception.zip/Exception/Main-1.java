package com.aulasdepoo.aula16.excecoespersonalizadas;

public class Main {
    public static void main(String[] args) {
        try {
            Data data = new Data(100, -100, 1000);
        } catch (DataException e) {
            e.printStackTrace();
        }
    }
}
