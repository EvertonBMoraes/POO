package Exception;

import java.util.InputMismatchException;
import java.util.Scanner;

public class CodigoPGExemplosExcecoes {

    /*Ao executar um programa, podem surgir alguns problemas que não ocorrem em uma situação normal,
    são falhas que fazem com que o programa pare ou aborte sua execução, “quebra”.
	O que podemos fazer ao lidar com exceções é que nossos programas sejam tolerantes a essas falhas e,
	se elas ocorrerem, que de alguma forma as resolvam.
	Dependendo do tipo de problema, o programa pode ignorá-lo e continuar, ou caso o problema seja grave
	e não possa continuar, com esta ferramenta, pode-se conseguir que dê um aviso ao usuário e termine
	em mais forma elegante e não apenas para de funcionar.
	Java também usa exceções para nos informar sobre erros que podemos corrigir no código.

	-> Todas as exceções herdam de Exception.
	-> Muitas das classes RuntimeExceptions são devidas a erros cometidos ao escrever o código.
	-> 	As IOExceptions são aquelas que não dependem do código, por exemplo, se no meu programa quero
	    abrir um arquivo ou salvar algo em um arquivo e o arquivo não está lá porque foi excluído ou
	    simplesmente se está danificado e não pode ser utilizado, este tipo de Exceção, que não é
	    da responsabilidade direta do programador, mas quando programamos estes tipos de ações,
	    devemos antecipar que podem ocorrer. IndexOutOfRangeException”, quando estamos usando um índice
	    que está fora do intervalo.
	-> ArithmeticException: operação aritmética inválida, operações que não podem ser resolvidas.
	-> InputMismatchException : Lançada pela classe Scanner, indica que o valor recuperado não
	   corresponde ao esperado*/

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int num1,num2, divisao;
        try { //Experimente
            /*o bloco try estão as instruções que podem gerar um problema
            * Os blocos try / catch nos permitem usar mais de uma captura.
            * Dessa forma, podemos lidar com exceções específicas primeiro
            * e, em seguida, as mais gerais.*/

            System.out.println("Primeiro número");
           // num1=scanner.nextInt(); para lançar a Exception
            num1 = Integer.parseInt(null);
            System.out.println("Segundo número");
            num2=scanner.nextInt();
            divisao = num1 / num2;
            System.out.println(divisao);

            /*O bloco catch “captura” a exceção e exibe ela de uma maneira mais amigável*/
        } catch (InputMismatchException e) { //Pegue
            /*Essa exceção acontece devido a uma entrada incorreta de valor*/
            System.err.println("Erro na entrada de dados, digite um valor inteiro");
        } catch (ArithmeticException e) { //Pegue
            /*Essa exceção acontece ao tentar dividir um valor por 0*/
            System.err.println("Erro - impossível divisão por zero");
        } catch(Exception e) { //Pegue
            /*Essa exceção é genérica e é lançada caso ocorra qualquer outro erro*/
            System.err.println("Erro");
        }

    }
}
